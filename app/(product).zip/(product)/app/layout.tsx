import AppShell from "@/components/shell/AppShell";
import { auth } from "@/auth";
import { redirect } from "next/navigation";
import "@/styles/app/globals.css";

export const metadata = {
  robots: { index: false, follow: false },
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await auth();
  if (!session) redirect("/api/auth/signin?callbackUrl=/app");

  return (
    <html lang="fi">
      <body>
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
