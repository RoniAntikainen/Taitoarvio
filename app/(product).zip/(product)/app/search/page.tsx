export default function SettingsPage() {
  return <div>Settings</div>;
}
