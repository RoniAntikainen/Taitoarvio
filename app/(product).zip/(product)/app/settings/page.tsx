import { auth } from "@/auth";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import MarketingConsentToggle from "@/components/marketing/MarketingConsentToggle";
import { getEntitlement } from "@/lib/access";

export const metadata = {
  robots: { index: false, follow: false },
  title: "Asetukset",
};

export default async function SettingsPage() {
  const session = await auth();
  if (!session?.user?.email) redirect("/api/auth/signin?callbackUrl=/app/settings");

  const user = await prisma.user.findUnique({
    where: { email: session.user.email },
    include: { subscription: true },
  });

  const ent = getEntitlement(session);

  return (
    <main id="main-content" style={{ maxWidth: 920, margin: "0 auto", padding: 24 }}>
      <h1>Asetukset</h1>

      <section style={{ marginTop: 18, padding: 16, borderRadius: 12, border: "1px solid rgba(0,0,0,0.12)" }}>
        <h2>Tilaus</h2>
        <p style={{ marginTop: 8 }}>
          Status: <b>{ent.status}</b>
        </p>
        {ent.trialEndsAt && (
          <p style={{ marginTop: 6, opacity: 0.85 }}>
            Kokeilu päättyy: {ent.trialEndsAt.toLocaleDateString("fi-FI")}
          </p>
        )}
        {ent.currentPeriodEnd && (
          <p style={{ marginTop: 6, opacity: 0.85 }}>
            Nykyinen jakso päättyy: {ent.currentPeriodEnd.toLocaleDateString("fi-FI")}
          </p>
        )}

        <form action="/api/billing/portal" method="post" style={{ marginTop: 12 }}>
          <button type="submit">Hallitse tilausta (Stripe)</button>
        </form>

        {!ent.hasPro && (
          <p style={{ marginTop: 10, fontSize: 13, opacity: 0.85 }}>
            Haluatko Pro-käyttöoikeuden? Siirry <a href="/pricing">hinnoitteluun</a>.
          </p>
        )}
      </section>

      <section style={{ marginTop: 18, padding: 16, borderRadius: 12, border: "1px solid rgba(0,0,0,0.12)" }}>
        <h2>Sähköpostiasetukset</h2>
        <p style={{ marginTop: 8, opacity: 0.85 }}>
          Palveluviestejä (kuitit, maksut, turvallisuus) voidaan lähettää tilin ylläpitoa varten.
          Markkinointiviestit vain suostumuksella.
        </p>

        <div style={{ marginTop: 12 }}>
          <MarketingConsentToggle initialConsent={!!user?.marketingConsent} />
        </div>
      </section>
    </main>
  );
}
