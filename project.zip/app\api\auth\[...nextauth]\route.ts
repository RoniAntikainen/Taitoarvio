export const runtime = "nodejs";

export { GET, POST } from "@/auth";
