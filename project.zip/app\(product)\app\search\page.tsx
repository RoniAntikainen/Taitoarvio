import "./search.css";

export default function SettingsPage() {
  return <div>Settings</div>;
}
